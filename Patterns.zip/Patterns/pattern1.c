#include<stdio.h>
int main(){
    int n;
    scanf("%d",&n);
    for(int col=0;col<n;col++){
        printf("*");
    }
}